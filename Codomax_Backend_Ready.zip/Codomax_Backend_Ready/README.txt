CODOMAX BLOG BACKEND - QUICK START

1. Extract this ZIP file.
2. Open the extracted Codomax_Backend_Ready folder in VS Code.
3. Double-click START_BACKEND.bat to install packages and start the server.
   Or in VS Code Terminal, run: npm install
   Then run: npm start
4. Open http://localhost:5000 in your browser.
5. You should see: {"message":"Codomax Blog Backend is running!"}

API:
GET    http://localhost:5000/api/blogs
POST   http://localhost:5000/api/blogs
GET    http://localhost:5000/api/blogs/1
DELETE http://localhost:5000/api/blogs/1

POST JSON example:
{"title":"My First Blog","content":"This is my first blog post."}

Note: This beginner demo stores blog posts in memory. Posts clear when the server restarts.
This backend must still be connected to your existing frontend to make the full app work.
