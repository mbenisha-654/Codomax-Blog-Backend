@echo off
title Codomax Blog Backend Setup
echo Checking Node.js...
node -v
if errorlevel 1 (
  echo Node.js was not found. Restart your computer after installing Node.js, then try again.
  pause
  exit /b 1
)
echo Installing backend packages. Please wait...
call npm install
if errorlevel 1 (
  echo Package installation failed. Check your internet connection and Node.js installation.
  pause
  exit /b 1
)
echo Starting Codomax Blog Backend...
call npm start
pause
