const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;
app.use(cors());
app.use(express.json());
let blogs = [];
let nextId = 1;
app.get("/", (req, res) => res.json({ message: "Codomax Blog Backend is running!" }));
app.get("/api/blogs", (req, res) => res.json(blogs));
app.post("/api/blogs", (req, res) => {
  const title = String(req.body.title || "").trim();
  const content = String(req.body.content || "").trim();
  if (!title || !content) return res.status(400).json({ message: "Title and content are required." });
  const blog = { id: nextId++, title, content, createdAt: new Date().toISOString() };
  blogs.push(blog);
  res.status(201).json({ message: "Blog published successfully.", blog });
});
app.get("/api/blogs/:id", (req, res) => {
  const blog = blogs.find(item => item.id === Number(req.params.id));
  if (!blog) return res.status(404).json({ message: "Blog not found." });
  res.json(blog);
});
app.delete("/api/blogs/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!blogs.some(blog => blog.id === id)) return res.status(404).json({ message: "Blog not found." });
  blogs = blogs.filter(blog => blog.id !== id);
  res.json({ message: "Blog deleted successfully." });
});
app.listen(PORT, () => console.log(`Codomax Blog Backend running at http://localhost:${PORT}`));
